# Implementation Plan — AI-Powered Personalized Learning and Exam Preparation for Ethiopian University Students

> **Note**: This project has been decomposed into 5 FEATs. The authoritative implementation artifacts are in `.agents/tasks/task-ethiopian-learning-platform/`. This plan.md is the fallback reference for the implement-and-review loop.

## Architecture Decisions

**Framework**: Next.js 14 App Router (not Pages Router) — chosen because the brief specifies it and it provides server components, route groups, and built-in API routes.

**Auth**: NextAuth.js v4 (next-auth@4.24.7) — NOT v5. v5 is in beta and has breaking API changes. All server-side auth uses `getServerSession(authOptions)`, not the v5 `auth()` function.

**DB**: Prisma + PostgreSQL. The Prisma singleton pattern (global variable) is mandatory to avoid exhausting DB connections during Next.js dev hot-reload.

**State**: Zustand for client state (exam answers, sidebar, theme). Server state is fetched fresh via Prisma in server components or via fetch() in client components.

**AI**: OpenAI gpt-4o via the official openai npm package. All AI calls go through `lib/openai.ts`.

---

## Critical TypeScript Gotchas

1. **Next.js 14 async params**: Dynamic route pages and API routes receive `params` as a Promise in Next.js 14. Always: `const { id } = await params` — never `params.id` directly.
2. **Prisma client singleton**: Use the `global.prisma` pattern in `lib/prisma.ts` to prevent "too many PrismaClient instances" error in dev.
3. **NextAuth type augmentation**: Extend `next-auth` module types to add `id`, `role`, `university` to `Session['user']` and `JWT`. Do this in `lib/auth.ts` or `types/next-auth.d.ts`.
4. **Prisma Json fields**: Cast `Json` fields via `as unknown as MyType[]` — don't leave as `any`.
5. **Client/Server boundary**: `next-auth/react` (signIn, signOut, useSession) is CLIENT only. `next-auth` (getServerSession) is SERVER only. Never mix.
6. **skipLibCheck**: Set `true` in tsconfig.json to avoid Radix UI type conflicts.
7. **GPT response parsing**: GPT-4o sometimes wraps JSON in markdown fences. Strip with: `content.replace(/^```json\n?/, '').replace(/\n?```$/, '')` before JSON.parse.

---

## Implementation Plan (ordered by dependency)

- [ ] 1. **Project scaffold and configuration**
      Create: `package.json`, `tsconfig.json`, `next.config.ts`, `tailwind.config.ts`, `postcss.config.js`, `.env.example`, `docker-compose.yml`, `.gitignore`.
      All dependencies pinned (see FEAT-001 for exact versions).
      Files: workspace root config files.
      Verify: `npm install` completes without errors.

- [ ] 2. **Prisma schema**
      Create `prisma/schema.prisma` with all 10 models: User, Account, Session, VerificationToken (exact @auth/prisma-adapter shape), Course, Enrollment, ExamSession, Question, FlashcardDeck, FlashcardProgress, ChatMessage, StudySession, Achievement.
      Files: `prisma/schema.prisma`
      Verify: `npx prisma validate` prints "The schema at prisma/schema.prisma is valid".

- [ ] 3. **Core library utilities and types**
      Create `lib/prisma.ts` (singleton), `lib/openai.ts`, `lib/auth.ts` (NextAuth config + type augmentation), `lib/utils.ts` (cn, formatDate, calculateGrade).
      Create `types/index.ts` with all shared interfaces.
      Create `store/index.ts` (Zustand), `hooks/useProgress.ts`.
      Files: `lib/`, `types/`, `store/`, `hooks/`
      Verify: `npx tsc --noEmit` — no errors in these files.

- [ ] 4. **shadcn/ui component library**
      Create all components in `components/ui/`: button, input, label, card, badge, dialog, dropdown-menu, tabs, progress, avatar, select, separator, toast/toaster, tooltip, skeleton.
      Files: `components/ui/*.tsx`, `hooks/use-toast.ts`
      Verify: `npx tsc --noEmit` — no type errors in components/ui/.

- [ ] 5. **Auth providers and root layout**
      Create `components/providers/ThemeProvider.tsx`, `app/layout.tsx` (root with Inter font + ThemeProvider + Toaster), `app/page.tsx` (landing page).
      Files: `app/layout.tsx`, `app/page.tsx`, `components/providers/ThemeProvider.tsx`
      Verify: `npm run build` — root layout and landing page compile.

- [ ] 6. **Auth API route and auth pages**
      Create `app/api/auth/[...nextauth]/route.ts`, `app/api/users/profile/route.ts`.
      Create `components/auth/LoginForm.tsx`, `components/auth/RegisterForm.tsx`.
      Create `app/(auth)/login/page.tsx`, `app/(auth)/register/page.tsx`.
      Files: `app/api/auth/`, `app/api/users/`, `app/(auth)/`, `components/auth/`
      Verify: `npm run build` — auth routes compile without errors.

- [ ] 7. **Dashboard layout and navigation**
      Create `components/dashboard/Sidebar.tsx`, `components/dashboard/TopNav.tsx`.
      Create `app/(dashboard)/layout.tsx` (session guard + layout).
      Files: `app/(dashboard)/layout.tsx`, `components/dashboard/`
      Verify: `npm run build` — dashboard layout compiles.

- [ ] 8. **Dashboard home page and stats components**
      Create `components/dashboard/StatsCard.tsx`, `WelcomeCard.tsx`, `RecentActivity.tsx`.
      Create `app/(dashboard)/dashboard/page.tsx`.
      Files: `app/(dashboard)/dashboard/page.tsx`, `components/dashboard/`
      Verify: `npm run build` — dashboard page compiles.

- [ ] 9. **Courses API routes and pages**
      Create `app/api/courses/route.ts`, `app/api/courses/[id]/route.ts`, `app/api/courses/[id]/enroll/route.ts`.
      Create `components/courses/CourseCard.tsx`, `CourseFilter.tsx`, `EnrollButton.tsx`, `ChapterAccordion.tsx`.
      Create `app/(dashboard)/courses/page.tsx`, `app/(dashboard)/courses/[id]/page.tsx`.
      Files: `app/api/courses/`, `app/(dashboard)/courses/`, `components/courses/`
      Verify: `npm run build` — all course files compile; params are awaited.

- [ ] 10. **Progress API and charts**
       Create `app/api/progress/route.ts`.
       Create `components/charts/ProgressChart.tsx`, `StudyTimeChart.tsx`, `CourseProgressChart.tsx`.
       Create `app/(dashboard)/progress/page.tsx`, `app/(dashboard)/profile/page.tsx`.
       Files: `app/api/progress/`, `app/(dashboard)/progress/`, `app/(dashboard)/profile/`, `components/charts/`
       Verify: `npm run build` — progress and profile pages compile.

- [ ] 11. **Exam preparation system**
       Create `app/api/exam/route.ts`, `app/api/exam/submit/route.ts`, `app/api/ai/generate-questions/route.ts`, `app/api/ai/learning-path/route.ts`.
       Create `components/exam/ExamSetup.tsx`, `ExamQuestion.tsx`, `ExamTimer.tsx`, `ExamResults.tsx`, `LearningPathDisplay.tsx`.
       Create `app/(dashboard)/exam-prep/page.tsx`, `app/(dashboard)/exam-prep/[id]/page.tsx`.
       Files: `app/api/exam/`, `app/api/ai/generate-questions/`, `app/api/ai/learning-path/`, `app/(dashboard)/exam-prep/`, `components/exam/`
       Verify: `npm run build` — exam files compile; no correctAnswer leaked to client.

- [ ] 12. **Flashcard system with spaced repetition**
       Create `app/api/flashcards/route.ts`, `app/api/flashcards/[id]/route.ts`, `app/api/flashcards/[id]/review/route.ts`, `app/api/ai/generate-flashcards/route.ts`.
       Create `components/flashcards/DeckCard.tsx`, `CreateDeckModal.tsx`, `FlashcardReview.tsx`, `AIGenerateCards.tsx`.
       Create `app/(dashboard)/flashcards/page.tsx`.
       Files: `app/api/flashcards/`, `app/api/ai/generate-flashcards/`, `app/(dashboard)/flashcards/`, `components/flashcards/`
       Verify: `npm run build` — flashcard files compile; SM-2 algorithm is present in review route.

- [ ] 13. **AI Tutor chat**
       Create `app/api/ai/chat/route.ts` (GET + POST).
       Create `components/ai-tutor/ChatMessage.tsx`, `ChatInput.tsx`, `ChatSidebar.tsx`, `ChatContainer.tsx`.
       Create `app/(dashboard)/ai-tutor/page.tsx`.
       Files: `app/api/ai/chat/`, `app/(dashboard)/ai-tutor/`, `components/ai-tutor/`
       Verify: `npm run build` — AI tutor files compile.

- [ ] 14. **Error/loading/not-found pages and loading skeletons**
       Create `app/not-found.tsx`, `app/error.tsx`, `app/loading.tsx`, `app/(dashboard)/loading.tsx`.
       Create loading.tsx in: `app/(dashboard)/courses/`, `app/(dashboard)/exam-prep/`, `app/(dashboard)/flashcards/`, `app/(dashboard)/ai-tutor/`.
       Files: various `loading.tsx`, `error.tsx`, `not-found.tsx`
       Verify: `npm run build` — all compile.

- [ ] 15. **Database seed data**
       Complete `prisma/seed.ts`: 3 demo users, 20+ courses across Ethiopian universities, 100+ exam questions, enrollments, study sessions, exam sessions.
       Files: `prisma/seed.ts`
       Verify: `npx prisma db seed` — runs without errors and inserts all records.

- [ ] 16. **ESLint config and final TypeScript audit**
       Create `.eslintrc.json`. Run `npm run lint`. Fix all lint errors.
       Audit all files for: async params, client/server boundary violations, Prisma Json casts, missing use-client directives, next-auth type augmentation completeness.
       Create `types/next-auth.d.ts` if augmentation is incomplete.
       Files: `.eslintrc.json`, `types/next-auth.d.ts`, any files with issues
       Verify: `npm run build` exits 0; `npm run lint` exits 0; `npx tsc --noEmit` exits 0.

- [ ] 17. **README.md**
       Create `README.md` with setup instructions, feature list, demo credentials, deployment notes.
       Files: `README.md`
       Verify: File exists and contains all sections listed in FEAT-005.

---

## Key File Dependencies (ordered)

```
package.json + tsconfig.json + tailwind.config.ts
  → prisma/schema.prisma
    → lib/prisma.ts
      → lib/auth.ts
        → app/api/auth/[...nextauth]/route.ts
      → lib/openai.ts
        → app/api/ai/*/route.ts
    → types/index.ts
      → store/index.ts
      → hooks/useProgress.ts
  → lib/utils.ts
    → components/ui/*.tsx
      → components/auth/*.tsx
      → components/dashboard/*.tsx
      → components/courses/*.tsx
      → components/exam/*.tsx
      → components/flashcards/*.tsx
      → components/ai-tutor/*.tsx
      → components/charts/*.tsx
        → app/(dashboard)/**/page.tsx
```
