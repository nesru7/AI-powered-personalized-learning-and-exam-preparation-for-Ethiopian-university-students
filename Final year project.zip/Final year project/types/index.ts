/**
 * types/index.ts
 *
 * Shared TypeScript interfaces and type aliases for the Ethiopian Learning
 * Platform. These types mirror the Prisma schema Json fields and are used
 * by both server components and client components.
 */

// ─── Primitive Aliases ────────────────────────────────────────────────────────

export type UserRole = 'student' | 'admin';

export type Difficulty = 'easy' | 'medium' | 'hard';

// ─── Chapter (stored as Json in Course.chapters) ─────────────────────────────

export interface ChapterType {
  order: number;
  title: string;
  content: string;
}

// ─── Course ───────────────────────────────────────────────────────────────────

export interface CourseWithEnrollment {
  id: string;
  title: string;
  description: string;
  department: string;
  university: string;
  year: number;
  chapters: ChapterType[];
  thumbnail: string | null;
  createdAt: Date;
  /** Present when fetched with the enrollment relation for a specific user */
  enrollment?: {
    id: string;
    progress: number;
    enrolledAt: Date;
  } | null;
}

// ─── Exam ─────────────────────────────────────────────────────────────────────

/** A single question as presented during an exam session */
export interface ExamQuestion {
  id: string;
  subject: string;
  text: string;
  /** Record<optionKey, optionText> — e.g. { A: '...', B: '...', C: '...', D: '...' } */
  options: Record<string, string>;
  correctAnswer: string;
  explanation: string;
  difficulty: Difficulty;
}

/** Summary returned after an exam session is completed */
export interface ExamSessionResult {
  id: string;
  subject: string;
  score: number;
  totalQuestions: number;
  /** Map of questionId → chosen answer key */
  answers: Record<string, string>;
  completedAt: Date;
}

// ─── Flashcards ───────────────────────────────────────────────────────────────

/** A single flashcard (stored inside FlashcardDeck.cards Json array) */
export interface FlashCard {
  index: number;
  front: string;
  back: string;
}

export interface FlashcardDeckWithProgress {
  id: string;
  title: string;
  subject: string;
  cards: FlashCard[];
  createdAt: Date;
  progress: Array<{
    cardIndex: number;
    ease: number;
    interval: number;
    nextReview: Date;
  }>;
}

// ─── AI Tutor ─────────────────────────────────────────────────────────────────

export interface ChatMessageType {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  createdAt: Date;
}

// ─── User Profile ─────────────────────────────────────────────────────────────

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  image: string | null;
  university: string | null;
  yearOfStudy: number | null;
  fieldOfStudy: string | null;
  role: UserRole;
  createdAt: Date;
}

// ─── Progress / Analytics ─────────────────────────────────────────────────────

export interface ProgressData {
  /** Total number of courses the user is enrolled in */
  totalCourses: number;
  /** Average progress across all enrollments (0–1) */
  averageProgress: number;
  /** Number of completed exam sessions */
  totalExams: number;
  /** Average exam score (0–100) */
  averageScore: number;
  /** Total study time in minutes */
  totalStudyMinutes: number;
  /** Number of achievements unlocked */
  achievementCount: number;
  /** Weekly study data for charts — last 7 days */
  weeklyStudy: Array<{
    date: string;
    minutes: number;
  }>;
  /** Per-subject score breakdown */
  subjectScores: Array<{
    subject: string;
    averageScore: number;
    examCount: number;
  }>;
}
