import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'
import { MaterialUploadForm } from '@/components/courses/MaterialUploadForm'

export default async function ManageMaterialsPage() {
  const session = await getServerSession(authOptions)
  if (session?.user?.role !== 'admin') redirect('/materials')

  const courses = await prisma.course.findMany({
    select: { id: true, title: true },
    orderBy: { title: 'asc' },
  })

  return (
    <section className="mx-auto max-w-2xl space-y-5">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Upload course material</h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">Upload a PDF or PowerPoint (.pptx). The AI extracts its text so students can ask questions and generate practice questions. Files are limited to 20 MB.</p>
      </div>
      {courses.length === 0 && <p role="alert" className="rounded-lg bg-amber-50 p-4 text-sm text-amber-900">Create a course before uploading materials.</p>}
      <MaterialUploadForm courses={courses} />
    </section>
  )
}
