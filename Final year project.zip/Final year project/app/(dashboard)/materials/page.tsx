import Link from 'next/link'
import { getServerSession } from 'next-auth'
import { redirect } from 'next/navigation'
import { FileText } from 'lucide-react'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'
import { GenerateMaterialQuestionsButton } from '@/components/courses/GenerateMaterialQuestionsButton'

export default async function MaterialsPage() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) redirect('/login')
  const materials = await prisma.courseMaterial.findMany({
    where: session?.user?.role === 'admin'
      ? {}
      : {
          published: true,
          course: { enrollments: { some: { userId: session.user.id } } },
        },
    select: {
      id: true,
      title: true,
      description: true,
      fileName: true,
      fileSize: true,
      createdAt: true,
      course: { select: { id: true, title: true } },
    },
    orderBy: { createdAt: 'desc' },
  })

  return (
    <section>
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Course materials</h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">Study from your course files with the AI tutor or generate practice questions from them.</p>
        </div>
        {session?.user?.role === 'admin' && (
          <Link href="/materials/manage" className="rounded-md bg-primary-900 px-4 py-2 text-sm font-medium text-white hover:bg-primary-800">Manage materials</Link>
        )}
      </div>
      {materials.length === 0 ? (
        <div className="mt-6 rounded-xl border bg-white p-8 text-center text-sm text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300">
          No materials are available yet. Enroll in a course to see its published reading files.
        </div>
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          {materials.map((material) => (
            <article key={material.id} className="rounded-xl border bg-white p-5 dark:border-slate-800 dark:bg-slate-950">
              <div className="flex items-start gap-3">
                <FileText className="mt-1 shrink-0 text-primary-800 dark:text-accent-400" />
                <div className="min-w-0">
                  <h2 className="font-semibold text-slate-900 dark:text-white">{material.title}</h2>
                  <p className="mt-1 text-sm text-slate-500">{material.course.title} · {material.fileName.toLowerCase().endsWith('.pptx') ? 'PowerPoint' : 'PDF'} · {(material.fileSize / (1024 * 1024)).toFixed(1)} MB</p>
                  {material.description && <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">{material.description}</p>}
                  <div className="mt-4 flex flex-wrap items-center gap-4">
                    <Link href={`/api/materials/${material.id}`} target="_blank" rel="noreferrer" className="text-sm font-semibold text-primary-800 hover:underline dark:text-accent-400">
                      Open original file
                    </Link>
                    <Link href="/ai-tutor" className="text-sm font-semibold text-primary-800 hover:underline dark:text-accent-400">
                      Ask AI tutor
                    </Link>
                  </div>
                  <GenerateMaterialQuestionsButton materialId={material.id} />
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  )
}
