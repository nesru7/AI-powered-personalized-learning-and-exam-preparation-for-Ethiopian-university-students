export default function ExamPrepLoading() {
  return <div className="animate-pulse space-y-5"><div className="h-10 w-72 rounded bg-slate-200 dark:bg-slate-800" /><div className="h-72 rounded-xl bg-slate-200 dark:bg-slate-800" /></div>
}
