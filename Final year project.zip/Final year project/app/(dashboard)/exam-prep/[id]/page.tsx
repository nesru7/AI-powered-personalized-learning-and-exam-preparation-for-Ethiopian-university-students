import { ExamRunner } from '@/components/exam/ExamRunner'

export default async function ExamSessionPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  return <ExamRunner examId={id} />
}
