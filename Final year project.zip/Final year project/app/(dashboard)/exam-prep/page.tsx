import Link from 'next/link'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'
import { ExamSetup } from '@/components/exam/ExamSetup'

export default async function ExamPrepPage() {
  const session = await getServerSession(authOptions)
  const recent = session?.user?.id ? await prisma.examSession.findMany({
    where: { userId: session.user.id },
    orderBy: { completedAt: 'desc' },
    take: 8,
    select: { id: true, subject: true, score: true, status: true, completedAt: true, totalQuestions: true },
  }) : []

  return (
    <section className="space-y-8">
      <div><p className="text-sm font-semibold uppercase tracking-wide text-accent-700">Exam preparation</p><h1 className="mt-1 text-3xl font-bold">Practice with confidence</h1><p className="mt-2 text-slate-600 dark:text-slate-300">Choose a subject and get immediate feedback on your answers.</p></div>
      <div className="grid gap-8 lg:grid-cols-[1.1fr_.9fr]">
        <div><h2 className="mb-3 text-lg font-semibold">Set up an exam</h2><ExamSetup /></div>
        <div><h2 className="mb-3 text-lg font-semibold">Recent attempts</h2>
          <div className="space-y-3">
            {recent.length === 0 && <p className="rounded-xl border bg-white p-5 text-sm text-slate-500 dark:bg-slate-950">Your completed exams will appear here.</p>}
            {recent.map((exam) => <Link key={exam.id} href={`/exam-prep/${exam.id}`} className="flex items-center justify-between rounded-xl border bg-white p-4 hover:shadow-sm dark:border-slate-800 dark:bg-slate-950">
              <div><p className="font-semibold">{exam.subject}</p><p className="text-sm text-slate-500">{exam.totalQuestions} questions · {new Date(exam.completedAt).toLocaleDateString()}</p></div>
              <span className="font-bold text-primary-900 dark:text-accent-400">{exam.status === 'completed' ? `${Math.round(exam.score)}%` : 'In progress'}</span>
            </Link>)}
          </div>
        </div>
      </div>
    </section>
  )
}
