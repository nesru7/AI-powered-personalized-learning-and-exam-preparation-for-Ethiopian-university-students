'use client'

import { FormEvent, useEffect, useState } from 'react'
import { Brain, Plus, RotateCcw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

type Card = { front: string; back: string }
type Deck = { id: string; title: string; subject: string; cards: Card[]; progress: Array<{ cardIndex: number }> }

export default function FlashcardsPage() {
  const [decks, setDecks] = useState<Deck[]>([])
  const [title, setTitle] = useState('')
  const [subject, setSubject] = useState('')
  const [front, setFront] = useState('')
  const [back, setBack] = useState('')
  const [cards, setCards] = useState<Card[]>([])
  const [activeDeck, setActiveDeck] = useState<Deck | null>(null)
  const [cardIndex, setCardIndex] = useState(0)
  const [flipped, setFlipped] = useState(false)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function loadDecks() {
    const response = await fetch('/api/flashcards')
    const body = await response.json()
    if (!response.ok) throw new Error(body.error ?? 'Could not load flashcard decks.')
    setDecks(body.decks)
  }

  useEffect(() => {
    loadDecks().catch((cause: unknown) => setError(cause instanceof Error ? cause.message : 'Could not load flashcards.'))
  }, [])

  function addCard(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!front.trim() || !back.trim()) return
    setCards((current) => [...current, { front: front.trim(), back: back.trim() }])
    setFront('')
    setBack('')
  }

  async function createDeck(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    setLoading(true)
    try {
      const response = await fetch('/api/flashcards', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, subject, cards }),
      })
      const body = await response.json()
      if (!response.ok) throw new Error(typeof body.error === 'string' ? body.error : 'Could not create deck.')
      setTitle('')
      setSubject('')
      setCards([])
      await loadDecks()
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not create deck.')
    } finally {
      setLoading(false)
    }
  }

  async function rate(rating: number) {
    if (!activeDeck) return
    try {
      const response = await fetch(`/api/flashcards/${activeDeck.id}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cardIndex, rating }),
      })
      const body = await response.json()
      if (!response.ok) throw new Error(body.error ?? 'Could not save review.')
      if (cardIndex + 1 >= activeDeck.cards.length) {
        setActiveDeck(null)
        await loadDecks()
      } else {
        setCardIndex((index) => index + 1)
        setFlipped(false)
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not save review.')
    }
  }

  if (activeDeck) {
    const card = activeDeck.cards[cardIndex]
    return (
      <section className="mx-auto max-w-2xl space-y-5">
        <div className="flex items-center justify-between"><div><p className="text-sm text-slate-500">{activeDeck.subject}</p><h1 className="text-2xl font-bold">{activeDeck.title}</h1></div><Button variant="outline" onClick={() => setActiveDeck(null)}>Exit study</Button></div>
        <div className="text-sm text-slate-500">Card {cardIndex + 1} of {activeDeck.cards.length}</div>
        <button onClick={() => setFlipped((value) => !value)} className="flex min-h-64 w-full flex-col items-center justify-center rounded-2xl border bg-white p-8 text-center shadow-sm dark:border-slate-800 dark:bg-slate-950">
          <p className="text-xs font-semibold uppercase tracking-wide text-accent-700">{flipped ? 'Answer' : 'Question'}</p>
          <p className="mt-4 text-2xl font-semibold">{flipped ? card.back : card.front}</p>
          <span className="mt-6 text-sm text-slate-500">Tap to flip</span>
        </button>
        {flipped && <div className="grid grid-cols-5 gap-2">{['Again', 'Hard', 'Good', 'Easy', 'Perfect'].map((label, index) => <Button key={label} variant="outline" onClick={() => void rate(index + 1)}>{label}</Button>)}</div>}
      </section>
    )
  }

  return (
    <section className="space-y-8">
      <div><p className="text-sm font-semibold uppercase tracking-wide text-accent-700">Spaced repetition</p><h1 className="mt-1 text-3xl font-bold">Flashcards</h1><p className="mt-2 text-slate-600 dark:text-slate-300">Create focused decks and strengthen recall with regular review.</p></div>
      {error && <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</p>}
      <div className="grid gap-8 lg:grid-cols-[.9fr_1.1fr]">
        <form onSubmit={createDeck} className="space-y-4 rounded-xl border bg-white p-5 dark:border-slate-800 dark:bg-slate-950">
          <h2 className="flex items-center gap-2 text-lg font-semibold"><Plus size={18} />Create a deck</h2>
          <Input required minLength={2} value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Deck title" />
          <Input required minLength={2} value={subject} onChange={(event) => setSubject(event.target.value)} placeholder="Subject" />
          <div className="space-y-2">
            <Input value={front} onChange={(event) => setFront(event.target.value)} placeholder="Card question / front" />
            <Input value={back} onChange={(event) => setBack(event.target.value)} placeholder="Answer / back" />
            <Button type="button" variant="outline" onClick={() => {
              if (front.trim() && back.trim()) {
                setCards((current) => [...current, { front: front.trim(), back: back.trim() }])
                setFront('')
                setBack('')
              }
            }}>Add card</Button>
          </div>
          <p className="text-xs text-slate-500">{cards.length} cards added (at least 3 required)</p>
          <div className="space-y-1">{cards.map((card, index) => <p key={`${card.front}-${index}`} className="truncate text-sm text-slate-600">{index + 1}. {card.front}</p>)}</div>
          <Button type="submit" disabled={loading || cards.length < 3}>{loading ? 'Creating…' : 'Save deck'}</Button>
        </form>
        <div>
          <h2 className="mb-4 text-lg font-semibold">Your decks</h2>
          {decks.length === 0 && <div className="rounded-xl border border-dashed p-8 text-center text-slate-500"><Brain className="mx-auto mb-3" /><p>No decks yet. Add three or more cards to create one.</p></div>}
          <div className="space-y-3">{decks.map((deck) => <article key={deck.id} className="flex items-center justify-between rounded-xl border bg-white p-4 dark:border-slate-800 dark:bg-slate-950">
            <div><p className="font-semibold">{deck.title}</p><p className="text-sm text-slate-500">{deck.subject} · {deck.cards.length} cards · {deck.progress.length} due</p></div>
            <Button size="sm" onClick={() => { setActiveDeck(deck); setCardIndex(0); setFlipped(false) }}><RotateCcw size={15} className="mr-2" />Study</Button>
          </article>)}</div>
        </div>
      </div>
    </section>
  )
}
