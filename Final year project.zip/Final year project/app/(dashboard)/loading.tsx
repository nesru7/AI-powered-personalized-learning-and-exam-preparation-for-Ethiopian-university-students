export default function DashboardLoading() {
  return (
    <div className="animate-pulse space-y-6">
      <div className="h-48 rounded-2xl bg-slate-200 dark:bg-slate-800" />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[1, 2, 3, 4].map((item) => <div key={item} className="h-32 rounded-xl bg-slate-200 dark:bg-slate-800" />)}
      </div>
    </div>
  )
}
