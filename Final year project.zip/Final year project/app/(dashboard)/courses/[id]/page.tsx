import Link from 'next/link'
import { notFound } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { BookOpen, ChevronLeft } from 'lucide-react'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'
import type { ChapterType } from '@/types'
import { EnrollButton } from '@/components/courses/EnrollButton'

export default async function CourseDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const session = await getServerSession(authOptions)
  const course = await prisma.course.findUnique({ where: { id } })
  if (!course) notFound()
  const enrollment = session?.user?.id
    ? await prisma.enrollment.findUnique({ where: { userId_courseId: { userId: session.user.id, courseId: id } } })
    : null
  const chapters = course.chapters as unknown as ChapterType[]

  return (
    <div className="mx-auto max-w-4xl space-y-7">
      <Link href="/courses" className="inline-flex items-center gap-1 text-sm font-medium text-primary-800 hover:underline dark:text-accent-400"><ChevronLeft size={16} />All courses</Link>
      <section className="rounded-2xl bg-gradient-to-r from-primary-900 to-primary-700 p-8 text-white">
        <p className="text-sm text-blue-100">{course.university} · {course.department} · Year {course.year}</p>
        <h1 className="mt-2 text-3xl font-bold">{course.title}</h1>
        <p className="mt-3 max-w-2xl text-blue-100">{course.description}</p>
        <div className="mt-6"><EnrollButton courseId={course.id} enrolled={Boolean(enrollment)} /></div>
      </section>
      <section>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Course chapters</h2>
        <div className="mt-4 space-y-3">
          {chapters.map((chapter) => (
            <article key={chapter.order} className="flex gap-4 rounded-xl border bg-white p-5 dark:border-slate-800 dark:bg-slate-950">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary-50 text-primary-900 dark:bg-slate-800 dark:text-accent-400"><BookOpen size={18} /></span>
              <div><p className="font-semibold text-slate-900 dark:text-white">{chapter.order}. {chapter.title}</p><p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{chapter.content}</p></div>
            </article>
          ))}
        </div>
      </section>
    </div>
  )
}
