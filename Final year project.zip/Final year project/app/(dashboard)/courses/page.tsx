import { CourseExplorer } from '@/components/courses/CourseExplorer'

export default function CoursesPage() {
  return (
    <section className="space-y-6">
      <div>
        <p className="text-sm font-semibold uppercase tracking-wide text-accent-700">Course library</p>
        <h1 className="mt-1 text-3xl font-bold text-slate-900 dark:text-white">Explore courses</h1>
        <p className="mt-2 text-slate-600 dark:text-slate-300">Find learning materials from universities across Ethiopia.</p>
      </div>
      <CourseExplorer />
    </section>
  )
}
