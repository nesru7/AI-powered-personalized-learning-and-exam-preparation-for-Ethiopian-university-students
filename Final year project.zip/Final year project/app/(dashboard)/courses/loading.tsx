export default function CoursesLoading() {
  return <div className="animate-pulse space-y-5"><div className="h-10 w-64 rounded bg-slate-200 dark:bg-slate-800" /><div className="grid gap-4 md:grid-cols-3">{[1, 2, 3, 4, 5, 6].map((item) => <div key={item} className="h-56 rounded-xl bg-slate-200 dark:bg-slate-800" />)}</div></div>
}
