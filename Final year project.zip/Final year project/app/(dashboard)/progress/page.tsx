'use client'

import { useEffect, useState } from 'react'
import { BarChart3, BookOpen, Clock3, FileQuestion, Trophy } from 'lucide-react'
import { StatsCard } from '@/components/dashboard/StatsCard'

type ProgressData = {
  enrollments: Array<{ id: string; progress: number; course: { title: string } }>
  scoreHistory: Array<{ date: string; score: number; subject: string }>
  weeklyStudy: Array<{ date: string; minutes: number }>
  totalStudyMinutes: number
  totalExams: number
  averageScore: number
  achievements: Array<{ id: string; type: string; unlockedAt: string }>
}

export default function ProgressPage() {
  const [data, setData] = useState<ProgressData | null>(null)
  const [error, setError] = useState('')
  useEffect(() => {
    fetch('/api/progress').then(async (response) => {
      const body = await response.json()
      if (!response.ok) throw new Error(body.error ?? 'Could not load progress.')
      setData(body)
    }).catch((cause: unknown) => setError(cause instanceof Error ? cause.message : 'Could not load progress.'))
  }, [])

  if (error) return <p role="alert" className="rounded-lg bg-red-50 p-4 text-red-700">{error}</p>
  if (!data) return <p className="text-slate-500">Loading your progress…</p>
  const maxMinutes = Math.max(30, ...data.weeklyStudy.map((day) => day.minutes))

  return (
    <section className="space-y-7">
      <div><p className="text-sm font-semibold uppercase tracking-wide text-accent-700">Learning analytics</p><h1 className="mt-1 text-3xl font-bold">Your progress</h1><p className="mt-2 text-slate-600 dark:text-slate-300">A snapshot of the learning habits you’re building.</p></div>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatsCard icon={BookOpen} label="Enrolled courses" value={data.enrollments.length} />
        <StatsCard icon={FileQuestion} label="Exams completed" value={data.totalExams} />
        <StatsCard icon={BarChart3} label="Average score" value={`${Math.round(data.averageScore)}%`} />
        <StatsCard icon={Clock3} label="Study time this week" value={`${data.totalStudyMinutes} min`} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <section className="rounded-xl border bg-white p-5 dark:border-slate-800 dark:bg-slate-950">
          <h2 className="font-semibold">Study time · last 7 days</h2>
          <div className="mt-6 flex h-48 items-end justify-around gap-2">
            {data.weeklyStudy.map((day) => <div key={day.date} className="flex h-full flex-1 flex-col items-center justify-end gap-2">
              <span className="text-xs text-slate-500">{day.minutes}m</span>
              <div className="w-full max-w-10 rounded-t-md bg-accent-500" style={{ height: `${Math.max(4, day.minutes / maxMinutes * 120)}px` }} />
              <span className="text-xs text-slate-500">{new Date(`${day.date}T12:00:00`).toLocaleDateString(undefined, { weekday: 'short' })}</span>
            </div>)}
          </div>
        </section>
        <section className="rounded-xl border bg-white p-5 dark:border-slate-800 dark:bg-slate-950">
          <h2 className="font-semibold">Course completion</h2>
          <div className="mt-5 space-y-4">
            {data.enrollments.length === 0 && <p className="text-sm text-slate-500">Enroll in a course to track your completion.</p>}
            {data.enrollments.map((item) => <div key={item.id}><div className="mb-1 flex justify-between gap-3 text-sm"><span className="truncate">{item.course.title}</span><span>{Math.round(item.progress)}%</span></div><div className="h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800"><div className="h-full rounded-full bg-primary-700" style={{ width: `${Math.min(100, Math.max(0, item.progress))}%` }} /></div></div>)}
          </div>
        </section>
      </div>
      <section className="rounded-xl border bg-white p-5 dark:border-slate-800 dark:bg-slate-950">
        <h2 className="flex items-center gap-2 font-semibold"><Trophy size={18} className="text-accent-600" />Achievements</h2>
        {data.achievements.length === 0 ? <p className="mt-3 text-sm text-slate-500">Complete exams and study sessions to earn achievements.</p> : <div className="mt-3 flex flex-wrap gap-2">{data.achievements.map((item) => <span key={item.id} className="rounded-full bg-accent-50 px-3 py-1 text-sm text-accent-800">{item.type}</span>)}</div>}
      </section>
    </section>
  )
}
