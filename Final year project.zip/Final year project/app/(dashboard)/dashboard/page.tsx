import Link from 'next/link'
import { getServerSession } from 'next-auth'
import { BookOpen, Bot, Clock3, FileQuestion, Layers3, TrendingUp } from 'lucide-react'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'
import { StatsCard } from '@/components/dashboard/StatsCard'

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)
  const userId = session?.user?.id
  if (!userId) return null

  const [user, enrollments, exams, decks, study] = await Promise.all([
    prisma.user.findUnique({ where: { id: userId }, select: { name: true, university: true, fieldOfStudy: true } }),
    prisma.enrollment.count({ where: { userId } }),
    prisma.examSession.findMany({ where: { userId, status: 'completed' }, select: { score: true }, take: 100 }),
    prisma.flashcardDeck.count({ where: { userId } }),
    prisma.studySession.aggregate({ where: { userId }, _sum: { durationMinutes: true } }),
  ])
  const average = exams.length ? Math.round(exams.reduce((sum, exam) => sum + exam.score, 0) / exams.length) : 0
  const greeting = new Intl.DateTimeFormat('en', { hour: 'numeric', hour12: false }).format(new Date())
  const welcome = Number(greeting) < 12 ? 'Good morning' : Number(greeting) < 17 ? 'Good afternoon' : 'Good evening'

  return (
    <div className="space-y-8">
      <section className="rounded-2xl bg-gradient-to-r from-primary-900 to-primary-700 p-7 text-white md:p-10">
        <p className="text-sm text-blue-100">{user?.university ?? 'Your learning dashboard'}</p>
        <h1 className="mt-2 text-3xl font-bold">{welcome}, {user?.name?.split(' ')[0] ?? 'Student'}!</h1>
        <p className="mt-2 max-w-2xl text-blue-100">
          {user?.fieldOfStudy ? `Continue building your ${user.fieldOfStudy} knowledge.` : 'Pick up where you left off and make today count.'}
        </p>
        <Link href="/courses" className="mt-6 inline-flex rounded-lg bg-accent-500 px-5 py-3 font-semibold text-slate-950 hover:bg-accent-400">
          Explore courses
        </Link>
      </section>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatsCard icon={BookOpen} label="Enrolled courses" value={enrollments} />
        <StatsCard icon={TrendingUp} label="Average exam score" value={`${average}%`} />
        <StatsCard icon={Layers3} label="Flashcard decks" value={decks} />
        <StatsCard icon={Clock3} label="Study time" value={`${study._sum.durationMinutes ?? 0} min`} />
      </section>

      <section>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Jump back in</h2>
        <div className="mt-4 grid gap-4 md:grid-cols-3">
          {[
            { href: '/courses', icon: BookOpen, title: 'Browse courses', text: 'Find course content from Ethiopian universities.' },
            { href: '/exam-prep', icon: FileQuestion, title: 'Practice for exams', text: 'Test your knowledge with focused questions.' },
            { href: '/ai-tutor', icon: Bot, title: 'Ask your AI tutor', text: 'Get explanations and study guidance.' },
          ].map(({ href, icon: Icon, title, text }) => (
            <Link key={href} href={href} className="rounded-xl border bg-white p-5 transition hover:-translate-y-0.5 hover:shadow-md dark:border-slate-800 dark:bg-slate-950">
              <Icon className="text-primary-700 dark:text-accent-400" size={22} />
              <h3 className="mt-4 font-semibold text-slate-900 dark:text-white">{title}</h3>
              <p className="mt-1 text-sm text-slate-500">{text}</p>
            </Link>
          ))}
        </div>
      </section>
    </div>
  )
}
