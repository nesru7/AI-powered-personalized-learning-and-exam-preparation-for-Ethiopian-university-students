export default function TutorLoading() {
  return <div className="animate-pulse grid h-[70vh] gap-5 lg:grid-cols-[1fr_280px]"><div className="rounded-xl bg-slate-200 dark:bg-slate-800" /><div className="rounded-xl bg-slate-200 dark:bg-slate-800" /></div>
}
