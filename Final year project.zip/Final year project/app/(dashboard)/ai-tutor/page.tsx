'use client'

import { FormEvent, useEffect, useRef, useState } from 'react'
import { Bot, Send } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'

type Message = { id?: string; role: 'user' | 'assistant'; content: string; createdAt?: string }
type Material = { id: string; title: string; course: { title: string } }

const suggestions = [
  'Explain the difference between a stack and a queue.',
  'Help me make a study plan for my next exam.',
  'What is the purpose of database normalization?',
  'Explain Newton’s second law with an example.',
]

export default function AiTutorPage() {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [materials, setMaterials] = useState<Material[]>([])
  const [materialId, setMaterialId] = useState('')
  const endRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    fetch('/api/ai/chat').then(async (response) => {
      const body = await response.json()
      if (!response.ok) throw new Error(body.error ?? 'Could not load conversation.')
      setMessages(body.messages)
      setMaterials(body.materials)
    }).catch((cause: unknown) => setError(cause instanceof Error ? cause.message : 'Could not load conversation.'))
  }, [])

  useEffect(() => endRef.current?.scrollIntoView({ behavior: 'smooth' }), [messages, loading])

  async function sendMessage(event?: FormEvent<HTMLFormElement>, text = input) {
    event?.preventDefault()
    const content = text.trim()
    if (!content || loading) return
    setInput('')
    setError('')
    setMessages((current) => [...current, { role: 'user', content }])
    setLoading(true)
    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: content, ...(materialId ? { materialId } : {}) }),
      })
      const body = await response.json()
      if (!response.ok) throw new Error(body.error ?? 'Could not send message.')
      setMessages((current) => [...current, body.message as Message])
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Could not send message.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <section className="grid min-h-[70vh] gap-5 lg:grid-cols-[1fr_280px]">
      <div className="flex min-h-[70vh] flex-col overflow-hidden rounded-xl border bg-white dark:border-slate-800 dark:bg-slate-950">
        <header className="flex items-center gap-3 border-b p-4 dark:border-slate-800"><span className="rounded-lg bg-primary-50 p-2 text-primary-900 dark:bg-slate-800 dark:text-accent-400"><Bot /></span><div><h1 className="font-bold">AI Tutor</h1><p className="text-xs text-slate-500">Ask questions and learn step by step</p></div></header>
        <div className="border-b p-3 dark:border-slate-800">
          <label htmlFor="tutor-material" className="mb-1 block text-sm font-medium">Answer from course material</label>
          <select id="tutor-material" value={materialId} onChange={(event) => setMaterialId(event.target.value)} className="w-full rounded-md border bg-white px-3 py-2 text-sm dark:bg-slate-900">
            <option value="">General AI tutor</option>
            {materials.map((material) => <option key={material.id} value={material.id}>{material.course.title} — {material.title}</option>)}
          </select>
          {materials.length === 0 && <p className="mt-1 text-xs text-slate-500">Enroll in a course with published materials to ask questions about its files.</p>}
        </div>
        <div className="flex-1 space-y-4 overflow-y-auto p-4">
          {messages.length === 0 && <div className="mx-auto mt-12 max-w-md text-center"><Bot className="mx-auto text-primary-800" size={36} /><h2 className="mt-4 font-semibold">What are you learning today?</h2><p className="mt-1 text-sm text-slate-500">Choose a prompt or ask your own question.</p></div>}
          {messages.map((message, index) => <div key={message.id ?? `${message.role}-${index}`} className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-3 text-sm ${message.role === 'user' ? 'ml-auto bg-primary-900 text-white' : 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-100'}`}>{message.content}</div>)}
          {loading && <p className="text-sm text-slate-500">Your tutor is thinking…</p>}
          <div ref={endRef} />
        </div>
        {error && <p role="alert" className="px-4 text-sm text-red-600">{error}</p>}
        <form onSubmit={(event) => void sendMessage(event)} className="flex items-end gap-2 border-t p-3 dark:border-slate-800">
          <Textarea value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={(event) => {
            if (event.key === 'Enter' && !event.shiftKey) {
              event.preventDefault()
              void sendMessage(undefined)
            }
          }} rows={2} placeholder="Ask a question… (Enter to send)" className="resize-none" />
          <Button type="submit" disabled={loading || !input.trim()} aria-label="Send message"><Send size={17} /></Button>
        </form>
      </div>
      <aside className="h-fit rounded-xl border bg-white p-5 dark:border-slate-800 dark:bg-slate-950">
        <h2 className="font-semibold">Try asking</h2>
        <div className="mt-3 space-y-2">{suggestions.map((suggestion) => <button key={suggestion} onClick={() => void sendMessage(undefined, suggestion)} disabled={loading} className="w-full rounded-lg bg-slate-50 p-3 text-left text-sm text-slate-700 hover:bg-primary-50 disabled:opacity-50 dark:bg-slate-900 dark:text-slate-300">{suggestion}</button>)}</div>
      </aside>
    </section>
  )
}
