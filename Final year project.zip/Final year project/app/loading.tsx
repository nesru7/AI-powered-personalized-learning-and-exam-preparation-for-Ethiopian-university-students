export default function Loading() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50">
      <div className="text-center">
        <div className="mx-auto h-10 w-10 animate-spin rounded-full border-4 border-primary-200 border-t-primary-900" />
        <p className="mt-4 font-semibold text-primary-900">EthioLearn</p>
        <p className="text-sm text-slate-500">Preparing your learning space…</p>
      </div>
    </div>
  )
}
