import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { ThemeProvider } from '@/components/providers/ThemeProvider'
import { SessionProvider } from '@/components/providers/SessionProvider'
import { Toaster } from '@/components/ui/toaster'
import { LanguageProvider } from '@/lib/translations'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'EthioLearn AI - Personalized Learning for Ethiopian Students',
  description: 'AI-powered personalized learning and exam preparation for Ethiopian university students',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <SessionProvider>
          <LanguageProvider>
            <ThemeProvider defaultTheme="light" storageKey="ethiolearn-theme">
              {children}
              <Toaster />
            </ThemeProvider>
          </LanguageProvider>
        </SessionProvider>
      </body>
    </html>
  )
}
