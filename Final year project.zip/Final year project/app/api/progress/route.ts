import { getServerSession } from 'next-auth'
import { NextResponse } from 'next/server'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const userId = session.user.id
  const [enrollments, exams, studySessions, achievements] = await Promise.all([
    prisma.enrollment.findMany({ where: { userId }, include: { course: { select: { id: true, title: true, university: true } } }, orderBy: { enrolledAt: 'desc' } }),
    prisma.examSession.findMany({ where: { userId, status: 'completed' }, select: { subject: true, score: true, completedAt: true }, orderBy: { completedAt: 'asc' } }),
    prisma.studySession.findMany({ where: { userId, date: { gte: new Date(Date.now() - 6 * 86400000) } }, select: { subject: true, durationMinutes: true, date: true } }),
    prisma.achievement.findMany({ where: { userId }, orderBy: { unlockedAt: 'desc' } }),
  ])
  const weeklyStudy = Array.from({ length: 7 }, (_, index) => {
    const date = new Date()
    date.setHours(0, 0, 0, 0)
    date.setDate(date.getDate() - (6 - index))
    const minutes = studySessions
      .filter((item) => item.date.toDateString() === date.toDateString())
      .reduce((total, item) => total + item.durationMinutes, 0)
    return { date: date.toISOString().slice(0, 10), minutes }
  })
  const scoreHistory = exams.map((exam) => ({ date: exam.completedAt.toISOString().slice(0, 10), score: exam.score, subject: exam.subject }))
  const totalStudyMinutes = studySessions.reduce((total, item) => total + item.durationMinutes, 0)
  const averageScore = exams.length ? exams.reduce((total, exam) => total + exam.score, 0) / exams.length : 0
  return NextResponse.json({
    enrollments,
    scoreHistory,
    weeklyStudy,
    totalStudyMinutes,
    totalExams: exams.length,
    averageScore,
    achievements,
  })
}
