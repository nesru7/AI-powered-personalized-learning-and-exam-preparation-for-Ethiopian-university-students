import { NextRequest, NextResponse } from 'next/server'
import { Prisma } from '@prisma/client'
import bcrypt from 'bcryptjs'
import { COMPUTING_DEPARTMENTS, ETHIOPIAN_UNIVERSITIES, LANGUAGES, THEMES } from '@/lib/education-options'
import prisma from '@/lib/prisma'

export async function POST(req: NextRequest) {
  if (!process.env.DATABASE_URL) {
    return NextResponse.json(
      { message: 'Registration is unavailable because the database is not configured. Set DATABASE_URL in .env.local and restart the development server.' },
      { status: 503 }
    )
  }

  try {
    const body = await req.json()
    const { name, email, password, university, yearOfStudy, fieldOfStudy, language, theme } = body

    if (
      typeof name !== 'string' || name.trim().length < 2 || name.trim().length > 100 ||
      typeof email !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ||
      typeof university !== 'string' || !ETHIOPIAN_UNIVERSITIES.includes(university) ||
      typeof fieldOfStudy !== 'string' || !COMPUTING_DEPARTMENTS.includes(fieldOfStudy as (typeof COMPUTING_DEPARTMENTS)[number]) ||
      !Number.isInteger(yearOfStudy) || yearOfStudy < 1 || yearOfStudy > 6 ||
      (language !== undefined && !LANGUAGES.includes(language)) ||
      (theme !== undefined && !THEMES.includes(theme))
    ) {
      return NextResponse.json(
        { message: 'Please enter valid registration details and choose an Ethiopian university, computing department, language, and theme.' },
        { status: 400 }
      )
    }

    if (typeof password !== 'string' || password.length < 8) {
      return NextResponse.json(
        { message: 'Password must be at least 8 characters.' },
        { status: 400 }
      )
    }

    // Check email uniqueness
    const existing = await prisma.user.findUnique({ where: { email } })
    if (existing) {
      return NextResponse.json(
        { message: 'An account with this email already exists.' },
        { status: 409 }
      )
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12)

    // Create user
    const user = await prisma.user.create({
      data: {
        name,
        email: email.trim().toLowerCase(),
        password: hashedPassword,
        university,
        yearOfStudy,
        fieldOfStudy,
        language: language ?? 'en',
        theme: theme ?? 'light',
      },
      select: {
        id: true,
        name: true,
        email: true,
        university: true,
        yearOfStudy: true,
        fieldOfStudy: true,
        createdAt: true,
      },
    })

    return NextResponse.json(user, { status: 201 })
  } catch (error) {
    console.error('[REGISTER]', error)

    if (error instanceof Prisma.PrismaClientInitializationError) {
      return NextResponse.json(
        { message: 'Registration is unavailable because the database cannot be reached. Check DATABASE_URL and make sure PostgreSQL is running.' },
        { status: 503 }
      )
    }

    return NextResponse.json(
      { message: 'Internal server error.' },
      { status: 500 }
    )
  }
}
