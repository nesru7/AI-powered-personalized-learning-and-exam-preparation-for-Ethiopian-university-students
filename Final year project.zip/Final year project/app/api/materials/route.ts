import { randomUUID } from 'node:crypto'
import { mkdir, unlink, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { getServerSession } from 'next-auth'
import { NextRequest, NextResponse } from 'next/server'
import { OfficeParser } from 'officeparser'
import prisma from '@/lib/prisma'
import { authOptions } from '@/lib/auth'
import { getMaterialStoragePath, getPdfWorkerUrl, MAX_MATERIAL_SIZE } from '@/lib/material-storage'

export const runtime = 'nodejs'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const materials = await prisma.courseMaterial.findMany({
    where: session.user.role === 'admin'
      ? {}
      : {
          published: true,
          course: { enrollments: { some: { userId: session.user.id } } },
        },
    select: {
      id: true,
      title: true,
      description: true,
      fileName: true,
      fileSize: true,
      published: true,
      createdAt: true,
      course: { select: { id: true, title: true } },
    },
    orderBy: { createdAt: 'desc' },
  })

  return NextResponse.json({ materials })
}

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
  if (session.user.role !== 'admin') {
    return NextResponse.json({ error: 'Only administrators can upload course materials.' }, { status: 403 })
  }

  const contentLength = Number(request.headers.get('content-length') ?? 0)
  if (contentLength > MAX_MATERIAL_SIZE + 64 * 1024) {
    return NextResponse.json({ error: 'The PDF or PowerPoint must be 20 MB or smaller.' }, { status: 413 })
  }

  let formData: FormData
  try {
    formData = await request.formData()
  } catch {
    return NextResponse.json({ error: 'Could not read the upload. Please submit a PDF or PowerPoint file.' }, { status: 400 })
  }

  const title = formData.get('title')
  const description = formData.get('description')
  const courseId = formData.get('courseId')
  const published = formData.get('published')
  const file = formData.get('file')

  if (typeof title !== 'string' || title.trim().length < 2 || title.trim().length > 150) {
    return NextResponse.json({ error: 'Title must be between 2 and 150 characters.' }, { status: 400 })
  }
  if (typeof courseId !== 'string' || !courseId) {
    return NextResponse.json({ error: 'Select a course for this material.' }, { status: 400 })
  }
  if (typeof description !== 'string' || description.length > 2000) {
    return NextResponse.json({ error: 'Description must be 2,000 characters or fewer.' }, { status: 400 })
  }
  if (!(file instanceof File) || file.size === 0) {
    return NextResponse.json({ error: 'Select a PDF or PowerPoint file to upload.' }, { status: 400 })
  }
  if (file.size > MAX_MATERIAL_SIZE) {
    return NextResponse.json({ error: 'The PDF or PowerPoint must be 20 MB or smaller.' }, { status: 413 })
  }

  const extension = file.name.toLowerCase().split('.').pop()
  if (extension !== 'pdf' && extension !== 'pptx') {
    return NextResponse.json({ error: 'Only PDF and PowerPoint (.pptx) files are supported.' }, { status: 400 })
  }

  const bytes = Buffer.from(await file.arrayBuffer())
  const isPdf = extension === 'pdf' && bytes.subarray(0, 5).equals(Buffer.from('%PDF-'))
  const isPowerPoint = extension === 'pptx' && bytes.subarray(0, 2).equals(Buffer.from('PK'))
  if (!isPdf && !isPowerPoint) {
    return NextResponse.json({ error: 'The uploaded file does not match a valid PDF or PowerPoint file.' }, { status: 400 })
  }

  const course = await prisma.course.findUnique({ where: { id: courseId }, select: { id: true } })
  if (!course) {
    return NextResponse.json({ error: 'The selected course was not found.' }, { status: 404 })
  }

  const storageKey = `${randomUUID()}.${extension}`
  const storagePath = getMaterialStoragePath(storageKey)
  await mkdir(path.dirname(storagePath), { recursive: true })
  await writeFile(storagePath, bytes, { flag: 'wx' })

  let extractedText: string
  try {
    const document = await OfficeParser.parseOffice(storagePath, { pdfWorkerSrc: getPdfWorkerUrl() })
    extractedText = document.toText().replace(/\u0000/g, '').trim().slice(0, 80000)
  } catch (error) {
    await unlink(storagePath)
    console.error('[MATERIAL_PARSE]', error)
    return NextResponse.json({ error: 'The file could not be read. Use a text-based PDF or a valid .pptx presentation.' }, { status: 400 })
  }
  if (extractedText.length < 40) {
    await unlink(storagePath)
    return NextResponse.json({ error: 'The file has too little readable text for the AI tutor. Check that it contains selectable text.' }, { status: 400 })
  }

  try {
    const material = await prisma.courseMaterial.create({
      data: {
        title: title.trim(),
        description: description.trim() || null,
        fileName: path.basename(file.name).slice(0, 255) || 'course-material.pdf',
        storageKey,
        fileSize: file.size,
        extractedText,
        published: published === 'true',
        courseId,
        uploadedById: session.user.id,
      },
      select: { id: true, title: true, published: true },
    })

    return NextResponse.json({ material }, { status: 201 })
  } catch (error) {
    await unlink(storagePath)
    throw error
  }
}
