import { readFile } from 'node:fs/promises'
import { getServerSession } from 'next-auth'
import { NextResponse } from 'next/server'
import { authOptions } from '@/lib/auth'
import { getMaterialContentType, getMaterialStoragePath } from '@/lib/material-storage'
import prisma from '@/lib/prisma'

export const runtime = 'nodejs'

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { id } = await context.params
  const material = await prisma.courseMaterial.findUnique({
    where: { id },
    select: { title: true, fileName: true, storageKey: true, published: true, courseId: true },
  })
  if (!material) {
    return NextResponse.json({ error: 'Material not found.' }, { status: 404 })
  }

  if (session.user.role !== 'admin') {
    if (!material.published) {
      return NextResponse.json({ error: 'Material not found.' }, { status: 404 })
    }
    const enrollment = await prisma.enrollment.findUnique({
      where: { userId_courseId: { userId: session.user.id, courseId: material.courseId } },
      select: { id: true },
    })
    if (!enrollment) {
      return NextResponse.json({ error: 'Enroll in this course to read its materials.' }, { status: 403 })
    }
  }

  try {
    const file = await readFile(getMaterialStoragePath(material.storageKey))
    const safeName = material.fileName.replace(/[\r\n"]/g, '_')
    return new NextResponse(file, {
      headers: {
        'Content-Type': getMaterialContentType(material.fileName),
        'Content-Disposition': `inline; filename="${safeName}"`,
        'Content-Length': String(file.byteLength),
        'X-Content-Type-Options': 'nosniff',
        'Cache-Control': 'private, no-store',
      },
    })
  } catch (error) {
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      console.error('[MATERIAL_FILE_MISSING]', { materialId: id, storageKey: material.storageKey })
      return NextResponse.json({ error: 'This file is temporarily unavailable. Please contact an administrator.' }, { status: 503 })
    }
    throw error
  }
}
