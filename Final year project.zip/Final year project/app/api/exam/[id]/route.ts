import { getServerSession } from 'next-auth'
import { NextResponse } from 'next/server'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { id } = await context.params
  const exam = await prisma.examSession.findFirst({ where: { id, userId: session.user.id } })
  if (!exam) return NextResponse.json({ error: 'Exam not found' }, { status: 404 })
  const storedAnswers = exam.answers as { questionIds?: unknown }
  const questionIds = Array.isArray(storedAnswers.questionIds)
    ? storedAnswers.questionIds.filter((questionId): questionId is string => typeof questionId === 'string')
    : []
  const questions = await prisma.question.findMany({ where: { id: { in: questionIds } } })
  const stored = exam.answers as Record<string, unknown>
  return NextResponse.json({
    exam: { id: exam.id, subject: exam.subject, status: exam.status, score: exam.score },
    questions: questions.map(({ id: questionId, subject, text, options, difficulty, correctAnswer, explanation }) => ({
      id: questionId,
      subject,
      text,
      options,
      difficulty,
      ...(exam.status === 'completed' ? { correctAnswer, explanation } : {}),
    })),
    ...(exam.status === 'completed' ? { answers: stored, score: exam.score } : {}),
  })
}
