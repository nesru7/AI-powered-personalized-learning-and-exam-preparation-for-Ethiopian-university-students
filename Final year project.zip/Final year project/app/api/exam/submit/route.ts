import { getServerSession } from 'next-auth'
import { NextResponse } from 'next/server'
import { z } from 'zod'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'

const submitSchema = z.object({
  sessionId: z.string().min(1),
  answers: z.record(z.string()),
})

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const parsed = submitSchema.safeParse(await request.json())
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
  const exam = await prisma.examSession.findFirst({
    where: { id: parsed.data.sessionId, userId: session.user.id },
  })
  if (!exam) return NextResponse.json({ error: 'Exam not found' }, { status: 404 })
  if (exam.status !== 'in_progress') return NextResponse.json({ error: 'This exam has already been submitted.' }, { status: 409 })
  const storedAnswers = exam.answers as { questionIds?: unknown }
  const questionIds = Array.isArray(storedAnswers.questionIds)
    ? storedAnswers.questionIds.filter((id): id is string => typeof id === 'string')
    : []
  if (questionIds.length !== exam.totalQuestions) {
    return NextResponse.json({ error: 'Exam data is incomplete. Please start a new exam.' }, { status: 409 })
  }
  const questions = await prisma.question.findMany({
    where: { id: { in: questionIds } },
  })
  const results = questions.map((question) => ({
    questionId: question.id,
    submitted: parsed.data.answers[question.id] ?? '',
    correct: question.correctAnswer,
    isCorrect: parsed.data.answers[question.id] === question.correctAnswer,
    explanation: question.explanation,
  }))
  const correctCount = results.filter((result) => result.isCorrect).length
  const score = results.length ? Math.round((correctCount / results.length) * 100) : 0
  await prisma.examSession.update({
    where: { id: exam.id },
    data: { score, answers: { ...parsed.data.answers, questionIds }, status: 'completed', completedAt: new Date() },
  })
  await prisma.studySession.create({
    data: { userId: session.user.id, subject: exam.subject, durationMinutes: 30 },
  })
  return NextResponse.json({ score, totalQuestions: results.length, correctCount, results })
}
