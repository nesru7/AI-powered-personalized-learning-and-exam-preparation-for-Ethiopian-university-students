import { getServerSession } from 'next-auth'
import { NextResponse } from 'next/server'
import { z } from 'zod'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const subjects = await prisma.question.findMany({
    where: {
      OR: [
        { materialId: null, courseId: null },
        { materialId: null, course: { enrollments: { some: { userId: session.user.id } } } },
        { material: { is: { published: true, course: { enrollments: { some: { userId: session.user.id } } } } } },
      ],
    },
    distinct: ['subject'],
    select: { subject: true },
    orderBy: { subject: 'asc' },
  })
  return NextResponse.json({ subjects: subjects.map(({ subject }) => subject) })
}

const startSchema = z.object({
  subject: z.string().min(1),
  questionCount: z.number().int().min(5).max(20).default(10),
  difficulty: z.enum(['easy', 'medium', 'hard', 'mixed']).default('mixed'),
})

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const parsed = startSchema.safeParse(await request.json())
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
  const where = {
    subject: parsed.data.subject,
    ...(parsed.data.difficulty === 'mixed' ? {} : { difficulty: parsed.data.difficulty }),
    OR: [
      { materialId: null, courseId: null },
      { materialId: null, course: { enrollments: { some: { userId: session.user.id } } } },
      { material: { is: { published: true, course: { enrollments: { some: { userId: session.user.id } } } } } },
    ],
  }
  const pool = await prisma.question.findMany({ where })
  if (pool.length < parsed.data.questionCount) {
    return NextResponse.json({ error: `Only ${pool.length} questions are available for this selection.` }, { status: 422 })
  }
  const questions = pool.sort(() => Math.random() - 0.5).slice(0, parsed.data.questionCount)
  const exam = await prisma.examSession.create({
    data: {
      userId: session.user.id,
      subject: parsed.data.subject,
      courseId: questions[0]?.courseId,
      totalQuestions: questions.length,
      status: 'in_progress',
      answers: { questionIds: questions.map(({ id }) => id) },
    },
  })
  return NextResponse.json({
    sessionId: exam.id,
    questions: questions.map(({ id, subject, text, options, difficulty }) => ({ id, subject, text, options, difficulty })),
  }, { status: 201 })
}
