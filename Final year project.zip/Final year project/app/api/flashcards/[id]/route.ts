import { getServerSession } from 'next-auth'
import { NextResponse } from 'next/server'
import { Prisma } from '@prisma/client'
import { z } from 'zod'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { id } = await context.params
  const deck = await prisma.flashcardDeck.findFirst({
    where: { id, userId: session.user.id },
    include: { progress: true },
  })
  if (!deck) return NextResponse.json({ error: 'Deck not found' }, { status: 404 })
  return NextResponse.json({ deck })
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { id } = await context.params
  const deck = await prisma.flashcardDeck.findFirst({ where: { id, userId: session.user.id }, select: { id: true } })
  if (!deck) return NextResponse.json({ error: 'Deck not found' }, { status: 404 })
  await prisma.flashcardDeck.delete({ where: { id } })
  return NextResponse.json({ success: true })
}

const updateSchema = z.object({
  title: z.string().trim().min(2).max(120).optional(),
  subject: z.string().trim().min(2).max(120).optional(),
  cards: z.array(z.object({ front: z.string().trim().min(1), back: z.string().trim().min(1) })).min(3).optional(),
})

export async function PUT(request: Request, context: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const parsed = updateSchema.safeParse(await request.json())
  if (!parsed.success || Object.keys(parsed.data ?? {}).length === 0) {
    return NextResponse.json({ error: parsed.success ? 'No deck fields provided.' : parsed.error.flatten() }, { status: 400 })
  }
  const { id } = await context.params
  const deck = await prisma.flashcardDeck.findFirst({ where: { id, userId: session.user.id }, select: { id: true } })
  if (!deck) return NextResponse.json({ error: 'Deck not found' }, { status: 404 })
  const data = {
    ...parsed.data,
    ...(parsed.data.cards ? { cards: parsed.data.cards as Prisma.InputJsonValue } : {}),
  }
  const updated = await prisma.flashcardDeck.update({ where: { id }, data })
  return NextResponse.json({ deck: updated })
}
