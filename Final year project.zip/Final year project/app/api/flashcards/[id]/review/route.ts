import { getServerSession } from 'next-auth'
import { NextResponse } from 'next/server'
import { z } from 'zod'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'

const reviewSchema = z.object({
  cardIndex: z.number().int().nonnegative(),
  rating: z.number().int().min(1).max(5),
})

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { id: deckId } = await context.params
  const parsed = reviewSchema.safeParse(await request.json())
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
  const deck = await prisma.flashcardDeck.findFirst({ where: { id: deckId, userId: session.user.id } })
  if (!deck) return NextResponse.json({ error: 'Deck not found' }, { status: 404 })
  const cards = Array.isArray(deck.cards) ? deck.cards : []
  if (parsed.data.cardIndex >= cards.length) return NextResponse.json({ error: 'Card index is out of range.' }, { status: 400 })
  const key = { userId_deckId_cardIndex: { userId: session.user.id, deckId, cardIndex: parsed.data.cardIndex } }
  const current = await prisma.flashcardProgress.findUnique({ where: key })
  const rating = parsed.data.rating
  const ease = Math.max(1.3, (current?.ease ?? 2.5) + 0.1 - (5 - rating) * (0.08 + (5 - rating) * 0.02))
  const interval = rating < 3 ? 1 : !current ? 1 : current.interval === 1 ? 6 : Math.round(current.interval * ease)
  const progress = await prisma.flashcardProgress.upsert({
    where: key,
    create: { ...key.userId_deckId_cardIndex, ease, interval, nextReview: new Date(Date.now() + interval * 86400000) },
    update: { ease, interval, nextReview: new Date(Date.now() + interval * 86400000) },
  })
  await prisma.studySession.create({ data: { userId: session.user.id, subject: deck.subject, durationMinutes: 1 } })
  return NextResponse.json({ progress })
}
