import { getServerSession } from 'next-auth'
import { NextResponse } from 'next/server'
import { Prisma } from '@prisma/client'
import { z } from 'zod'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const decks = await prisma.flashcardDeck.findMany({
    where: { userId: session.user.id },
    include: { progress: { where: { nextReview: { lte: new Date() } }, select: { cardIndex: true } } },
    orderBy: { createdAt: 'desc' },
  })
  return NextResponse.json({ decks })
}

const deckSchema = z.object({
  title: z.string().trim().min(2).max(120),
  subject: z.string().trim().min(2).max(120),
  cards: z.array(z.object({ front: z.string().trim().min(1), back: z.string().trim().min(1) })).min(3),
})

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const parsed = deckSchema.safeParse(await request.json())
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
  const deck = await prisma.flashcardDeck.create({
    data: { ...parsed.data, userId: session.user.id, cards: parsed.data.cards as Prisma.InputJsonValue },
  })
  return NextResponse.json({ deck }, { status: 201 })
}
