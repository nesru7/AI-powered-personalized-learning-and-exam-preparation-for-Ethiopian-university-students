import { getServerSession } from 'next-auth'
import { NextResponse } from 'next/server'
import { z } from 'zod'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'
import { generateCompletion } from '@/lib/openai'

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const body = z.object({ subject: z.string().trim().min(2).max(120) }).safeParse(await request.json())
  if (!body.success) return NextResponse.json({ error: body.error.flatten() }, { status: 400 })
  try {
    const exams = await prisma.examSession.findMany({
      where: { userId: session.user.id, subject: body.data.subject, status: 'completed' },
      select: { score: true, completedAt: true },
      orderBy: { completedAt: 'desc' },
      take: 10,
    })
    const plan = await generateCompletion([
      { role: 'system', content: 'Create practical, encouraging study plans for Ethiopian university students. Keep the answer concise and specific.' },
      { role: 'user', content: `Make a four-week study plan for ${body.data.subject}. Recent scores: ${exams.map((exam) => `${Math.round(exam.score)}%`).join(', ') || 'no exams yet'}. Organize it by week with daily goals and useful resource types.` },
    ])
    return NextResponse.json({ plan })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unable to build a learning plan.'
    return NextResponse.json({ error: message }, { status: message.includes('OPENAI_API_KEY') ? 503 : 502 })
  }
}
