import { getServerSession } from 'next-auth'
import { NextResponse } from 'next/server'
import { Prisma } from '@prisma/client'
import { z } from 'zod'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'
import { generateCompletion } from '@/lib/openai'

const schema = z.object({
  subject: z.string().trim().min(2).max(120),
  count: z.number().int().min(5).max(20).default(10),
  difficulty: z.enum(['easy', 'medium', 'hard']).default('medium'),
})

const generatedQuestion = z.object({
  text: z.string().min(8),
  options: z.object({ A: z.string(), B: z.string(), C: z.string(), D: z.string() }),
  correctAnswer: z.enum(['A', 'B', 'C', 'D']),
  explanation: z.string().min(8),
  difficulty: z.enum(['easy', 'medium', 'hard']),
})

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const parsed = schema.safeParse(await request.json())
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
  try {
    const content = await generateCompletion([{
      role: 'user',
      content: `Generate ${parsed.data.count} original multiple-choice questions for Ethiopian university students studying ${parsed.data.subject}. Difficulty: ${parsed.data.difficulty}. Each item must have text, options (A/B/C/D strings), correctAnswer (A/B/C/D), explanation, and difficulty. Return only a JSON array.`,
    }])
    const json = content.replace(/^\s*```(?:json)?\s*/i, '').replace(/\s*```\s*$/, '')
    const questions = z.array(generatedQuestion).min(1).parse(JSON.parse(json))
    const saved = await prisma.question.createMany({
      data: questions.map((question) => ({
        ...question,
        subject: parsed.data.subject,
        options: question.options as Prisma.InputJsonValue,
      })),
    })
    return NextResponse.json({ generatedCount: saved.count })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unable to generate exam questions.'
    return NextResponse.json({ error: message }, { status: message.includes('OPENAI_API_KEY') ? 503 : 502 })
  }
}
