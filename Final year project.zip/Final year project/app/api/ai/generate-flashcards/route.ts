import { getServerSession } from 'next-auth'
import { NextResponse } from 'next/server'
import { z } from 'zod'
import { authOptions } from '@/lib/auth'
import { generateCompletion } from '@/lib/openai'

const schema = z.object({
  subject: z.string().trim().min(2).max(120),
  topic: z.string().trim().min(2).max(200),
  count: z.number().int().min(3).max(20).default(8),
})

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const parsed = schema.safeParse(await request.json())
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
  try {
    const content = await generateCompletion([{
      role: 'user',
      content: `Create ${parsed.data.count} accurate flashcards for Ethiopian university students about "${parsed.data.topic}" in ${parsed.data.subject}. Return only a JSON array of objects with string "front" and "back" fields.`,
    }])
    const json = content.replace(/^\s*```(?:json)?\s*/i, '').replace(/\s*```\s*$/, '')
    const cards = z.array(z.object({ front: z.string().min(1), back: z.string().min(1) })).min(3).parse(JSON.parse(json))
    return NextResponse.json({ cards })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unable to generate cards.'
    return NextResponse.json({ error: message }, { status: message.includes('OPENAI_API_KEY') ? 503 : 502 })
  }
}
