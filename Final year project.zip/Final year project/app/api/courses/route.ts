import { getServerSession } from 'next-auth'
import { NextResponse } from 'next/server'
import { z } from 'zod'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const university = searchParams.get('university')
  const department = searchParams.get('department')
  const courses = await prisma.course.findMany({
    where: {
      ...(university ? { university } : {}),
      ...(department ? { department } : {}),
    },
    orderBy: [{ university: 'asc' }, { department: 'asc' }, { year: 'asc' }],
  })
  return NextResponse.json({ courses })
}

const courseSchema = z.object({
  title: z.string().trim().min(3).max(150),
  description: z.string().trim().min(10).max(3000),
  department: z.string().trim().min(2).max(120),
  university: z.string().trim().min(2).max(150),
  year: z.number().int().min(1).max(6),
  chapters: z.array(z.object({ order: z.number().int().positive(), title: z.string(), content: z.string() })).min(1),
})

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (session.user.role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const parsed = courseSchema.safeParse(await request.json())
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
  const course = await prisma.course.create({ data: parsed.data })
  return NextResponse.json({ course }, { status: 201 })
}
