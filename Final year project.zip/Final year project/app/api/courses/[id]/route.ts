import { getServerSession } from 'next-auth'
import { NextResponse } from 'next/server'
import { z } from 'zod'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params
  const session = await getServerSession(authOptions)
  const course = await prisma.course.findUnique({
    where: { id },
    include: { enrollments: session?.user?.id ? { where: { userId: session.user.id } } : false },
  })
  if (!course) return NextResponse.json({ error: 'Course not found' }, { status: 404 })
  return NextResponse.json({ course, enrolled: 'enrollments' in course && course.enrollments.length > 0 })
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (session.user.role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const { id } = await context.params
  await prisma.course.delete({ where: { id } })
  return NextResponse.json({ success: true })
}

const updateSchema = z.object({
  title: z.string().trim().min(3).max(150).optional(),
  description: z.string().trim().min(10).max(3000).optional(),
  department: z.string().trim().min(2).max(120).optional(),
  university: z.string().trim().min(2).max(150).optional(),
  year: z.number().int().min(1).max(6).optional(),
  chapters: z.array(z.object({ order: z.number().int().positive(), title: z.string(), content: z.string() })).min(1).optional(),
})

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (session.user.role !== 'admin') return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const parsed = updateSchema.safeParse(await request.json())
  if (!parsed.success || Object.keys(parsed.data ?? {}).length === 0) {
    return NextResponse.json({ error: parsed.success ? 'No course fields provided.' : parsed.error.flatten() }, { status: 400 })
  }
  const { id } = await context.params
  const course = await prisma.course.update({ where: { id }, data: parsed.data })
  return NextResponse.json({ course })
}
