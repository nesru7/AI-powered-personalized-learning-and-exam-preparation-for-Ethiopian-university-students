import bcrypt from 'bcryptjs'
import { encode } from 'next-auth/jwt'
import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function POST(req: Request) {
  try {
    const { name, email, password, university, fieldOfStudy, yearOfStudy } = await req.json()

    if (!name || !email || !password) {
      return NextResponse.json({ error: 'Name, email, and password are required' }, { status: 400 })
    }

    const normalizedEmail = email.toLowerCase().trim()

    const existingUser = await prisma.user.findUnique({
      where: { email: normalizedEmail },
    })

    if (existingUser) {
      return NextResponse.json({ error: 'Email is already registered' }, { status: 400 })
    }

    const hashedPassword = await bcrypt.hash(password, 10)

    const user = await prisma.user.create({
      data: {
        name: name.trim(),
        email: normalizedEmail,
        password: hashedPassword,
        university: university || 'Addis Ababa University',
        fieldOfStudy: fieldOfStudy || 'Computer Science',
        yearOfStudy: yearOfStudy ? parseInt(yearOfStudy, 10) : 4,
        role: 'student',
      },
    })

    const secret = process.env.NEXTAUTH_SECRET || 'development-secret-key-ethiolearn-ai-2025'

    const token = await encode({
      token: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        university: user.university,
      },
      secret,
    })

    return NextResponse.json({
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        university: user.university,
        language: user.language,
        theme: user.theme,
      },
    })
  } catch (error) {
    console.error('Mobile registration error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
