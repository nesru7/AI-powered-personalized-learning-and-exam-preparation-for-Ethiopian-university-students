import Link from 'next/link'
import { GraduationCap } from 'lucide-react'
import { LoginForm } from '@/components/auth/LoginForm'

export default function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-[#1e3a5f] px-4 py-12">
      <div className="w-full max-w-md">
        {/* Logo / Brand */}
        <div className="mb-8 flex flex-col items-center text-center">
          <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-white shadow-lg">
            <GraduationCap className="h-8 w-8 text-[#1e3a5f]" />
          </div>
          <h1 className="text-2xl font-bold text-white">EthioLearn AI</h1>
          <p className="mt-1 text-sm text-blue-200">AI-Powered Learning for Ethiopian Students</p>
        </div>

        {/* Card */}
        <div className="rounded-2xl bg-white p-8 shadow-xl">
          <h2 className="mb-1 text-xl font-semibold text-gray-900">Welcome back</h2>
          <p className="mb-6 text-sm text-gray-500">Sign in to continue your learning journey</p>
          <LoginForm />
        </div>

        {/* Register link */}
        <p className="mt-6 text-center text-sm text-blue-200">
          Don&apos;t have an account?{' '}
          <Link href="/register" className="font-semibold text-[#f59e0b] hover:underline">
            Create one free
          </Link>
        </p>
      </div>
    </div>
  )
}
