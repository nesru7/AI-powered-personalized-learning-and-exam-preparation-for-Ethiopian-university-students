import Link from 'next/link'
import { GraduationCap } from 'lucide-react'
import { RegisterForm } from '@/components/auth/RegisterForm'

export default function RegisterPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-[#1e3a5f] px-4 py-12">
      <div className="w-full max-w-lg">
        {/* Logo / Brand */}
        <div className="mb-8 flex flex-col items-center text-center">
          <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-white shadow-lg">
            <GraduationCap className="h-8 w-8 text-[#1e3a5f]" />
          </div>
          <h1 className="text-2xl font-bold text-white">EthioLearn AI</h1>
          <p className="mt-1 text-sm text-blue-200">Create your free account</p>
        </div>

        {/* Card */}
        <div className="rounded-2xl bg-white p-8 shadow-xl">
          <h2 className="mb-1 text-xl font-semibold text-gray-900">Get started</h2>
          <p className="mb-6 text-sm text-gray-500">Fill in your details to create an account</p>
          <RegisterForm />
        </div>

        {/* Login link */}
        <p className="mt-6 text-center text-sm text-blue-200">
          Already have an account?{' '}
          <Link href="/login" className="font-semibold text-[#f59e0b] hover:underline">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  )
}
