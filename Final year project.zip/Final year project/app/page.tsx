'use client'

import Link from 'next/link'
import { BookOpen, Brain, BarChart3, Zap, Star, GraduationCap, Users, Award } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'

const UNIVERSITIES = [
  'Addis Ababa University',
  'Bahir Dar University',
  'Jimma University',
  'Hawassa University',
  'Mekelle University',
  'Haramaya University',
  'Adama Science and Technology University',
  'Arba Minch University',
  'Dire Dawa University',
  'Woldia University',
  'Debre Markos University',
  'Gondar University',
  'Wollega University',
  'Dilla University',
  'Mizan-Tepi University',
  'Madda Walabu University',
]

const BADGE_COLORS = [
  'bg-blue-100 text-blue-800',
  'bg-green-100 text-green-800',
  'bg-purple-100 text-purple-800',
  'bg-orange-100 text-orange-800',
  'bg-pink-100 text-pink-800',
  'bg-teal-100 text-teal-800',
  'bg-indigo-100 text-indigo-800',
  'bg-red-100 text-red-800',
  'bg-yellow-100 text-yellow-800',
  'bg-cyan-100 text-cyan-800',
  'bg-emerald-100 text-emerald-800',
  'bg-violet-100 text-violet-800',
  'bg-rose-100 text-rose-800',
  'bg-sky-100 text-sky-800',
  'bg-lime-100 text-lime-800',
]

const FEATURES = [
  {
    icon: Brain,
    title: 'AI Tutor',
    description:
      'Get instant answers and explanations from our AI tutor trained on Ethiopian university curricula. Ask questions in Amharic or English.',
  },
  {
    icon: BookOpen,
    title: 'Exam Preparation',
    description:
      'Access thousands of past exam questions with step-by-step solutions, curated for Ethiopian university entrance and course exams.',
  },
  {
    icon: Zap,
    title: 'Smart Flashcards',
    description:
      'Reinforce your learning with AI-generated flashcards using spaced repetition to help you retain information more effectively.',
  },
  {
    icon: BarChart3,
    title: 'Progress Analytics',
    description:
      'Track your performance with detailed analytics. Identify weak areas and get personalized recommendations to improve your grades.',
  },
]

const TESTIMONIALS = [
  {
    name: 'Nesru Abu',
    university: 'Madda Walabu University',
    year: '4th Year, Computer Science',
    text: 'EthioLearn AI helped me prepare for my final exams. The AI tutor explained complex algorithms in a way I could understand.',
    initials: 'TA',
    rating: 5,
  },
  {
    name: 'Gemechis Reta',
    university: 'Bahir Dar University',
    year: '4th Year, computer science',
    text: 'The exam prep feature is incredible. I practiced hundreds of past questions and my grades improved significantly this semester.',
    initials: 'DB',
    rating: 5,
  },
  {
    name: 'jemal Hassen',
    university: 'Jimma University',
    year: '4th Year, information system',
    text: 'As a medical student, the flashcard system saves hours of memorisation. The spaced repetition really works for anatomy.',
    initials: 'SH',
    rating: 5,
  },
]

const STATS = [
  { value: '10,000+', label: 'Active Students' },
  { value: '500+', label: 'Courses Covered' },
  { value: '15', label: 'Universities' },
  { value: '98%', label: 'Satisfaction Rate' },
]

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* ─── Navigation ──────────────────────────────────────────── */}
      <nav className="sticky top-0 z-50 border-b border-gray-200 bg-white/95 backdrop-blur-sm">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#1e3a5f]">
              <GraduationCap className="h-5 w-5 text-white" />
            </div>
            <span className="text-xl font-bold text-[#1e3a5f]">EthioLearn AI</span>
          </div>

          {/* Desktop nav links */}
          <div className="hidden items-center gap-8 md:flex">
            <a href="#features" className="text-sm font-medium text-gray-600 transition-colors hover:text-[#1e3a5f]">
              Features
            </a>
            <a href="#courses" className="text-sm font-medium text-gray-600 transition-colors hover:text-[#1e3a5f]">
              Courses
            </a>
            <a href="#about" className="text-sm font-medium text-gray-600 transition-colors hover:text-[#1e3a5f]">
              About
            </a>
          </div>

          {/* CTA buttons */}
          <div className="flex items-center gap-3">
            <Link href="/login">
              <Button variant="outline" size="sm">
                Sign In
              </Button>
            </Link>
            <Link href="/register">
              <Button size="sm" className="bg-[#f59e0b] text-white hover:bg-[#d97706]">
                Get Started
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* ─── Hero ────────────────────────────────────────────────── */}
      <section className="bg-gradient-to-br from-[#1e3a5f] via-[#2f5390] to-[#1e3a5f] px-4 py-24 text-white sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl text-center">
          <Badge className="mb-6 bg-[#f59e0b]/20 text-[#f59e0b] hover:bg-[#f59e0b]/30 border-[#f59e0b]/30">
            🎓 Powered by Advanced AI
          </Badge>
          <h1 className="mb-6 text-4xl font-bold leading-tight tracking-tight sm:text-5xl lg:text-6xl">
            AI-Powered Learning for{' '}
            <span className="text-[#f59e0b]">Ethiopian University</span> Students
          </h1>
          <p className="mx-auto mb-10 max-w-2xl text-lg text-blue-100 sm:text-xl">
            Personalised study plans, AI tutoring, exam preparation, and smart flashcards — all designed
            for the Ethiopian university curriculum.
          </p>
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link href="/register">
              <Button size="lg" className="w-full bg-[#f59e0b] text-white hover:bg-[#d97706] sm:w-auto">
                Start Learning Free
              </Button>
            </Link>
            <Link href="#features">
              <Button
                size="lg"
                variant="outline"
                className="w-full border-white text-white hover:bg-white/10 sm:w-auto"
              >
                Explore Features
              </Button>
            </Link>
          </div>

          {/* Stats */}
          <div className="mt-16 grid grid-cols-2 gap-6 sm:grid-cols-4">
            {STATS.map((stat) => (
              <div key={stat.label} className="rounded-xl bg-white/10 px-4 py-6 backdrop-blur-sm">
                <p className="text-3xl font-bold text-[#f59e0b]">{stat.value}</p>
                <p className="mt-1 text-sm text-blue-100">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Features ────────────────────────────────────────────── */}
      <section id="features" className="px-4 py-24 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="mb-16 text-center">
            <h2 className="mb-4 text-3xl font-bold text-[#1e3a5f] sm:text-4xl">
              Everything You Need to Succeed
            </h2>
            <p className="mx-auto max-w-xl text-gray-500">
              Purpose-built tools that adapt to your learning style and help you achieve your academic goals.
            </p>
          </div>

          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {FEATURES.map((feature) => (
              <Card key={feature.title} className="group border-gray-200 transition-shadow hover:shadow-lg">
                <CardHeader>
                  <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-[#1e3a5f]/10 group-hover:bg-[#1e3a5f] transition-colors">
                    <feature.icon className="h-6 w-6 text-[#1e3a5f] group-hover:text-white transition-colors" />
                  </div>
                  <CardTitle className="text-lg text-[#1e3a5f]">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-sm leading-relaxed text-gray-500">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Universities ─────────────────────────────────────────── */}
      <section id="courses" className="bg-gray-50 px-4 py-24 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="mb-12 text-center">
            <h2 className="mb-4 text-3xl font-bold text-[#1e3a5f] sm:text-4xl">
              Serving 15 Ethiopian Universities
            </h2>
            <p className="text-gray-500">
              Curriculum-aligned content for every major Ethiopian university.
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-3">
            {UNIVERSITIES.map((university, index) => (
              <span
                key={university}
                className={`inline-flex items-center rounded-full px-4 py-2 text-sm font-medium ${BADGE_COLORS[index % BADGE_COLORS.length]}`}
              >
                {university}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Testimonials ─────────────────────────────────────────── */}
      <section id="about" className="px-4 py-24 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="mb-16 text-center">
            <h2 className="mb-4 text-3xl font-bold text-[#1e3a5f] sm:text-4xl">
              Loved by Ethiopian Students
            </h2>
            <p className="text-gray-500">Hear from students who transformed their learning journey.</p>
          </div>

          <div className="grid gap-8 sm:grid-cols-3">
            {TESTIMONIALS.map((testimonial) => (
              <Card key={testimonial.name} className="border-gray-200 shadow-sm">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Avatar className="h-12 w-12">
                      <AvatarFallback className="bg-[#1e3a5f] text-white font-semibold">
                        {testimonial.initials}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold text-gray-900">{testimonial.name}</p>
                      <p className="text-xs text-gray-500">{testimonial.year}</p>
                      <p className="text-xs text-[#1e3a5f]">{testimonial.university}</p>
                    </div>
                  </div>
                  {/* Stars */}
                  <div className="flex gap-0.5 pt-1">
                    {Array.from({ length: testimonial.rating }).map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-[#f59e0b] text-[#f59e0b]" />
                    ))}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm leading-relaxed text-gray-600">&quot;{testimonial.text}&quot;</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* ─── CTA Banner ───────────────────────────────────────────── */}
      <section className="bg-[#1e3a5f] px-4 py-20 text-white sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <Users className="mx-auto mb-4 h-12 w-12 text-[#f59e0b]" />
          <h2 className="mb-4 text-3xl font-bold sm:text-4xl">
            Join 10,000+ Students Achieving More
          </h2>
          <p className="mb-8 text-blue-100">
            Sign up free today and get access to AI tutoring, exam prep, and personalised study plans.
          </p>
          <Link href="/register">
            <Button size="lg" className="bg-[#f59e0b] text-white hover:bg-[#d97706]">
              Get Started — It&apos;s Free
            </Button>
          </Link>
        </div>
      </section>

      {/* ─── Footer ───────────────────────────────────────────────── */}
      <footer className="border-t border-gray-200 bg-white px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-col items-center justify-between gap-6 sm:flex-row">
            {/* Brand */}
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#1e3a5f]">
                <GraduationCap className="h-4 w-4 text-white" />
              </div>
              <span className="font-bold text-[#1e3a5f]">EthioLearn AI</span>
            </div>

            {/* Links */}
            <div className="flex gap-6 text-sm text-gray-500">
              <Link href="#features" className="hover:text-[#1e3a5f] transition-colors">Features</Link>
              <Link href="#courses" className="hover:text-[#1e3a5f] transition-colors">Courses</Link>
              <Link href="/login" className="hover:text-[#1e3a5f] transition-colors">Sign In</Link>
              <Link href="/register" className="hover:text-[#1e3a5f] transition-colors">Register</Link>
            </div>

            {/* Copyright */}
            <p className="text-sm text-gray-400">
              © {new Date().getFullYear()} EthioLearn AI. All rights reserved.
            </p>
          </div>

          <div className="mt-6 flex flex-wrap justify-center gap-4 text-xs text-gray-400">
            <span className="flex items-center gap-1">
              <Award className="h-3 w-3" /> Ethiopian Ministry of Education Aligned
            </span>
            <span>|</span>
            <span>Built for Ethiopian University Students</span>
          </div>
        </div>
      </footer>
    </div>
  )
}
