import { withAuth } from 'next-auth/middleware'
import { NextResponse } from 'next/server'

export default withAuth(
  function middleware() {
    return NextResponse.next()
  },
  {
    callbacks: {
      authorized: ({ token }) => !!token,
    },
  }
)

export const config = {
  matcher: [
    '/dashboard/:path*',
    '/courses/:path*',
    '/exam-prep/:path*',
    '/flashcards/:path*',
    '/ai-tutor/:path*',
    '/progress/:path*',
    '/profile/:path*',
  ],
}
